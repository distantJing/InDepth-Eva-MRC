
import json
import os
import sys
sys.path.append('..')
# from re import A
# import argparse
# from botocore import args
# from nltk.util import pr
from Skill import tokenization
from Skill.input_example import InputAnswerExtractionExample
from stanfordcorenlp import StanfordCoreNLP
# from input_ablation_ans_extr import generate_ablated_input
# from run_ans_extr import tokenize_with_positions, generate_tokenized_examples
from Skill.run_ans_extr import generate_tokenized_examples


# parsed_doc / parsed_example: {
"""	
改为按照did和qid分开的格式，测试的时候只传一篇文章
parsed_data = 
{
qid:
	{s
	"doc":
		{
			"sentences":
			{
				"tokens":
				{
					"word":"my",
				 	"pos":1,
					"property":PREP,
				 	... 		 
					},

					{
					} 
				}, 
			}	
		},
	"query":
		{
			"sentences":
			{
				"tokens":
				{
					"word":"my",
				 	"pos":1,
					"property":PREP,
				 	... 		 
					},
					{
			
					} 
				}, 
			}
		}
	}
}
"""
def is_whitespace(c):
    if c == " " or c == "\t" or c == "\r" or c == "\n" or ord(c) == 0x202F or ord(c) == 160:
        return True
    return False



def corenlp_squad(savepath,dataset,loadpath,corenlp):
	nlp = StanfordCoreNLP(corenlp)
	
	# data = json.load(open("../squad_v1.1/dev-v1.1.json", "rb"))
	with open(loadpath, "r", encoding='utf-8') as reader:
		data = json.load(reader)["data"]
	parsed_data = {}
	# parsed_data["sentences"] = []
	for entry in data:
		for paragraph in entry["paragraphs"]:
			paragraph_text = paragraph["context"]
			sentences = paragraph_text.split('.')
			# doc
			sents = []
			for sent in sentences:
				if len(sent) == 0:
					continue
				sent += '.'
				# print(sent)
				# return
				sentence = {}
				sentence["tokens"] = []
				# print(sent)
				words = nlp.pos_tag(sent)
				pos = 0
				for word in words:
					token = {}
					token["pos"] = pos
					pos += 1
					token["word"] = word[0]
					token["property"] = word[1]
					sentence["tokens"].append(token)
				sents.append(sentence)
			for qa in paragraph["qas"]:
				qid = qa["id"]
				parsed_data[qid] = {}
				parsed_data[qid]["doc"] = {}
				parsed_data[qid]["query"] = {}
				parsed_data[qid]["doc"]["sentences"] = sents
				question_text = qa["question"]
				q_sents = []
				sentences = question_text.split('.')
				for sent in sentences:
					if len(sent) == 0:
						continue
					sentence = {}
					sentence["tokens"] = []
					# print(sent)
					words = nlp.pos_tag(sent)
					pos = 0
					for word in words:
						token = {}
						token["pos"] = pos
						pos += 1
						token["word"] = word[0]
						token["property"] = word[1]
						sentence["tokens"].append(token)
					q_sents.append(sentence)
				parsed_data[qid]["query"]["sentences"] = q_sents	
	# nlp.__exit__()
	if os.path.exists(savepath):
		pass
	else:
		os.makedirs(savepath)
	if os.path.exists(savepath+"/corenlp_"+dataset+".json"):
		pass
	else:
		with open(savepath+"/corenlp_"+dataset+".json", 'w', encoding='utf-8') as file_obj:
			json.dump(parsed_data, file_obj)
def test(skill,dataset,loadpath):
	with open(loadpath, "r", encoding='utf-8') as reader:
		data = json.load(reader)["data"]
	examples = []
	doc_count = 0
	for entry in data:
		for paragraph in entry["paragraphs"]:
			paragraph_text = paragraph["context"]
			doc_tokens = []
			char_to_word_offset = []
			prev_is_whitespace = True
			for c in paragraph_text:
				if is_whitespace(c):
					prev_is_whitespace = True
				else:
					if prev_is_whitespace:
						doc_tokens.append(c)
					else:
						doc_tokens[-1] += c
					prev_is_whitespace = False
				char_to_word_offset.append(len(doc_tokens) - 1)
			doc_count += 1
			doc_id = '{}-{}'.format("squad", doc_count)
			for qa in paragraph["qas"]:
				qas_id = qa["id"]
				question_text = qa["question"]
				start_position = None
				end_position = None
				orig_answer_text = None
				is_impossible = False
				if not is_impossible:
					answer = qa["answers"][0]
					orig_answer_text = answer["text"]
					orig_answer_texts = [a['text'] for a in qa["answers"]]
					answer_offset = answer["answer_start"]
					answer_length = len(orig_answer_text)
					start_position = char_to_word_offset[answer_offset]
					end_position = char_to_word_offset[answer_offset + answer_length - 1]
					# print(question_text, orig_answer_text, start_position, end_position)
					# return examples
					actual_text = " ".join(doc_tokens[start_position:(end_position + 1)])
					cleaned_answer_text = " ".join(
						tokenization.whitespace_tokenize(orig_answer_text))
					if actual_text.find(cleaned_answer_text) == -1:
						print("Could not find answer: '%s' vs. '%s'",
							actual_text, cleaned_answer_text)
						# continue
				else:
					start_position = -1
					end_position = -1
					orig_answer_text = ''
					orig_answer_texts = []
				example = InputAnswerExtractionExample(
	                    did=doc_id,
	                    qid=qas_id,
	                    query_text=question_text,
	                    doc_tokens=doc_tokens,
	                    orig_answer_text=orig_answer_text,
	                    start_position=start_position,
	                    end_position=end_position,
	                    orig_answer_texts=orig_answer_texts,
	                    is_impossible=is_impossible)
				examples.append(example)
	for example in examples:
		example.input_ablation = skill
	return examples
def convert_skill_format_to_squad_formant(input_data):
    data_squad_format = {"data":[]}
    for qid in input_data.keys(): 
        x = input_data[qid]
        data_ = {"paragraphs":
                    [
						{"context":x["doc_tokens"],
                     "qas":[
                         {"id":qid,
                          "question":x["question_text"],
                          "answers":[{"text":x["orig_answer_text"],
                                      "answer_start":0}]
                         }]
                    }
					]
                }
        data_squad_format["data"].append(data_)
    return data_squad_format
def main(skill=None,savepath=None,dataset=None,loadpath=None,corenlp=None):
	savepath = savepath+'/'+dataset
	if os.path.exists(savepath):
		pass
	else:
		os.makedirs(savepath)
# 
	if os.path.exists(savepath+"/corenlp_"+dataset+".json"):
		pass
	else:
		corenlp_squad(savepath,dataset,loadpath,corenlp)
	examples = test(skill,dataset,loadpath)
	corenlp_cache = json.load(open(savepath+"/corenlp_"+dataset+".json", "rb"))
	tokenized_examples = generate_tokenized_examples(
                examples,
                None,
                corenlp_cache,
                None,
                None,
            )
	data_dict = {}
	for ex in tokenized_examples:
		try:
			data_dict[ex.qid] = {
            "doc_tokens": " ".join(ex.doc_tokens),
            "question_text": " ".join(ex.query_tokens),
            "orig_answer_text": ex.orig_answer_text,
            "start_position": ex.start_position,
            "end_position": ex.end_position,
            "is_impossible": ex.is_impossible
        }
		except:
			data_dict[ex.qid] = {
            "doc_tokens": ex.doc_tokens,
            "question_text": ex.query_tokens,
            "orig_answer_text": ex.orig_answer_text,
            "start_position": ex.start_position,
            "end_position": ex.end_position,
            "is_impossible": ex.is_impossible
        }
	data_squad_format = convert_skill_format_to_squad_formant(data_dict)
	save_data = savepath+'/'+skill
	if os.path.exists(save_data):
		pass
	else:
		os.makedirs(save_data)
	with open(save_data+"/dev.json", 'a', encoding='utf-8') as file_obj:
		json.dump(data_squad_format, file_obj)
